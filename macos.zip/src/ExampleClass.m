classdef ExampleClass
    %EXAMPLECLASS An example class
    %   Has no properties or methods
    
    properties
    end
    
    methods
    end
    
end

