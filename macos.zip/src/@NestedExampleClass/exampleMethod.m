function [ Y ] = exampleMethod( X )
    Y = X;
end
