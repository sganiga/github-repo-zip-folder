classdef NestedExampleClass

    properties
    end
    
    methods
        Y = exampleMethod(X)
    end
    
end

