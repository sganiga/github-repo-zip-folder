function [ Y ] = exampleFunction( X )
%EXAMPLEFUNCTION An example of a function
%   Returns the argument passed

    Y = X;
end
