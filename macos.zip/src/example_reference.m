%% exampleFunction
% 
% <<../example.png>>
% 
% Using |exampleFunction|:
%
exampleFunction(42)

%% With other functions
%
% The output of |exampleFunction| may be passed to another function:
plot(exampleFunction(magic(3)))