%% exampleScript

X = 42;
Y = X.*X;

disp(Y)