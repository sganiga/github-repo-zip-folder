A = 2;
B = 2;

disp(A+B);