function x = identity(x)
%IDENTITY Returns the value passed as an argument
    x;
end
